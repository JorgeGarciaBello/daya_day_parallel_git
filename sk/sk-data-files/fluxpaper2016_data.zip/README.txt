
This directory contains ROOT files in which the histgrams used for the paper:

  "Measurements of the atmospheric neutrino flux by Super-Kamiokande:
    Energy spectra, geomagnetic effects, and solar modulation"

  Physical Review D 94, 052001 (2016)
  http://journals.aps.org/prd/abstract/10.1103/PhysRevD.94.052001
  arXiv:1510.08127

are included. The list and brief description of ROOT objects are shown below.

Contact:
  Kimihiro Okumura   <okumura@icrr.u-tokyo.ac.jp>
  Euan Richard       <richard@icrr.u-tokyo.ac.jp>


--------------------------------------------------------------------

Figure 2  
  Filename:  plot_Mj.root
  KEY: TH1D	fig2_data;1	Data
  KEY: TH1D	fig2_mc;1	MC total
  KEY: TH1D	fig2_nue;1	MC nu_e CC
  KEY: TH1D	fig2_num;1	MC nu_mu CC
  KEY: TH1D	fig2_nut;1	MC nu_tau CC
  KEY: TH1D	fig2_nc;1	MC NC


Figure 6
  Filename:  plot_error.root
  KEY: TH1D  err_statsyst;1	   Total
  KEY: TH1D  err_statonly;1	   Statistical only
  KEY: TH1D  err_xsec;1		   Neutrino interaction error
  KEY: TH1D  err_det;1		   Detector error 
  KEY: TH1D  err_other;1	   Oscillation and regularization error


Figure 9  
  Filename:  plot_matrix.root
  KEY: TMatrixT<double>	matcor_statonly;1    Correlation matrix of statistical error
  KEY: TMatrixT<double>	matcor_systonly;1    Correlation matrix of systematic error
  KEY: TMatrixT<double>	matcor_statsyst;1    Correlation matrix of stat+syst  error  (figure2)


Figure 10  
  Filename:  plot_error.root
  KEY: TGraphErrors	gr_nue_norm;1	     fitted normalization, nu_e
  KEY: TGraphErrors	gr_num_norm;1	     fitted normalization, nu_mu
  KEY: TGraphErrors	gr_nue_index;1	     fitted spec index, nu_e
  KEY: TGraphErrors	gr_num_index;1	     fitted spec index, nu_mu


Figure 14
  Filename: plot_external.root
  KEY: TGraphErrors	gr_sk_nue;1	        SK nu_e  energy spectrum 
  KEY: TGraphErrors	gr_sk_num;1	        SK nu_mu energy spectrum 
  KEY: TGraph		gr_hkkm11_nue_osc;1	HKKM11 nu_e  flux (w/ osc)
  KEY: TGraph		gr_hkkm11_num_osc;1	HKKM11 nu_mu flux (w/ osc)


Figure 19
  Filename: section4figures.root
  KEY: TH1D	fig19_nue_xxx;1        azimuthal angle for nu_e
  KEY: TH1D	fig19_numu_xxx;1       azimuthal angle for nu_mu
     0<=xxx<=3 : plot for different energy
     4<=xxx<=8 : plot for different zenith angle


Figure 20
  Filename: section4figures.root
  azimuthal angle for e-like/mu-like sample
  KEY: TH1D    fig20_numu_mc_xxx;1         MC with statistical error
  KEY: TH1D    fig20_numu_error_xxx;1      MC with systematic error
  KEY: TH1D    fig20_numu_data_xxx;1       Data
  KEY: TH1D    fig20_nue_mc_xxx;1          MC with statistical error
  KEY: TH1D    fig20_nue_error_xxx;1       MC with systematic error
  KEY: TH1D    fig20_nue_data_xxx;1        Data
     0<=xxx<=3 : plot for different energy
     4<=xxx<=8 : plot for different zenith angle


Figure 21 
  Filename: section4figures.root
  parameter A for e-like/mu-like as a function of zenith or energy 
  KEY: TH1D    fig21_nue_data_zenith;1	   
  KEY: TH1D    fig21_numu_data_zenith;1	   
  KEY: TH1D    fig21_nue_data_energy;1	   
  KEY: TH1D    fig21_numu_data_energy;1	   
  KEY: TH1D    fig21_nue_mc_zenith;1	   
  KEY: TH1D    fig21_numu_mc_zenith;1	   
  KEY: TH1D    fig21_nue_mc_energy;1	   
  KEY: TH1D    fig21_numu_mc_energy;1	   


Figure 22
  Filename: section4figures.root
  azimuthal distributions for e-like/mu-like 
  KEY: TH1D    fig22_nue_data;1		   Data
  KEY: TH1D    fig22_nue_mc;1		   MC with statistical error
  KEY: TH1D    fig22_nue_systerror;1	   MC with systematic error
  KEY: TH1D    fig22_numu_data;1	   
  KEY: TH1D    fig22_numu_mc;1		   
  KEY: TH1D    fig22_numu_systerror;1	   


Figure 23
  Filename: section4figures.root
  parameter B for e-like/mu-like as a function of cosine zenith 
  KEY: TH1D    fig23_nue_data;1		   
  KEY: TH1D    fig23_numu_data;1	   
  KEY: TH1D    fig23_nue_mc;1		   
  KEY: TH1D    fig23_numu_mc;1		   


Figure 24
  predicted normalization change of numu/nue flux
  Filename: section5figures.root
  KEY: TH2D    fig24_numu;1		   
  KEY: TH2D    fig24_numubar;1		   
  KEY: TH2D    fig24_nue;1		   
  KEY: TH2D    fig24_nuebar;1		   

Figure 27
  Filename: section5figures.root
  KEY: TGraph  fig27_e_up;1		   
  KEY: TGraph  fig27_e_down;1		   
  KEY: TGraph  fig27_mu_up;1		   
  KEY: TGraph  fig27_mu_down;1		   

Figure 29
  Filename: section5figures.root
  KEY: TH1D    fig29_e_up;1		   NM count vs. events
  KEY: TH1D    fig29_e_down;1		   NM count vs. events
  KEY: TH1D    fig29_mu_up;1		   NM count vs. events
  KEY: TH1D    fig29_mu_down;1		   NM count vs. events

Figure 30
  neutrino event rate as a funcion of NM parameter 
  Filename: section5figures.root
  KEY: TGraphAsymmErrors		   fig30_e_up_data;1	e-like up-going
  KEY: TF1				   fig30_e_up_model;1	
  KEY: TGraphAsymmErrors		   fig30_e_down_data;1	e-like down-going
  KEY: TF1				   fig30_e_down_model;1	
  KEY: TGraphAsymmErrors		   fig30_mu_up_data;1	#mu-like up-going
  KEY: TF1				   fig30_mu_up_model;1	
  KEY: TGraphAsymmErrors		   fig30_mu_down_data;1	#mu-like down-going
  KEY: TF1				   fig30_mu_down_model;1	 


Figure 31
  test statistic as a function of solar modulation strength parameter.
  Filename: section5figures.root
  KEY: TGraph				   fig31_lambda;1		 

Figure 32
  best fit alpha parameter for each SK period and subsamples.
  Filename: section5figures.root
  KEY: TH1D				   fig32_data;1			 


Figure 33
  seasonable variation of event rate.
  Filename: section5figures.root
  KEY: TH1D				   fig33_multigev;1		 
  KEY: TH1D				   fig33_subgev;1		 
